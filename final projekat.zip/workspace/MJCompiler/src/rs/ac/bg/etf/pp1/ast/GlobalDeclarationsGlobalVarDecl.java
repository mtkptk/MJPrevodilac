// generated with ast extension for cup
// version 0.8
// 13/0/2024 21:45:25


package rs.ac.bg.etf.pp1.ast;

public class GlobalDeclarationsGlobalVarDecl extends ConstDeclVarDeclClassDeclList {

    private ConstDeclVarDeclClassDeclList ConstDeclVarDeclClassDeclList;
    private GlobalVarDecl GlobalVarDecl;

    public GlobalDeclarationsGlobalVarDecl (ConstDeclVarDeclClassDeclList ConstDeclVarDeclClassDeclList, GlobalVarDecl GlobalVarDecl) {
        this.ConstDeclVarDeclClassDeclList=ConstDeclVarDeclClassDeclList;
        if(ConstDeclVarDeclClassDeclList!=null) ConstDeclVarDeclClassDeclList.setParent(this);
        this.GlobalVarDecl=GlobalVarDecl;
        if(GlobalVarDecl!=null) GlobalVarDecl.setParent(this);
    }

    public ConstDeclVarDeclClassDeclList getConstDeclVarDeclClassDeclList() {
        return ConstDeclVarDeclClassDeclList;
    }

    public void setConstDeclVarDeclClassDeclList(ConstDeclVarDeclClassDeclList ConstDeclVarDeclClassDeclList) {
        this.ConstDeclVarDeclClassDeclList=ConstDeclVarDeclClassDeclList;
    }

    public GlobalVarDecl getGlobalVarDecl() {
        return GlobalVarDecl;
    }

    public void setGlobalVarDecl(GlobalVarDecl GlobalVarDecl) {
        this.GlobalVarDecl=GlobalVarDecl;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(ConstDeclVarDeclClassDeclList!=null) ConstDeclVarDeclClassDeclList.accept(visitor);
        if(GlobalVarDecl!=null) GlobalVarDecl.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(ConstDeclVarDeclClassDeclList!=null) ConstDeclVarDeclClassDeclList.traverseTopDown(visitor);
        if(GlobalVarDecl!=null) GlobalVarDecl.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(ConstDeclVarDeclClassDeclList!=null) ConstDeclVarDeclClassDeclList.traverseBottomUp(visitor);
        if(GlobalVarDecl!=null) GlobalVarDecl.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("GlobalDeclarationsGlobalVarDecl(\n");

        if(ConstDeclVarDeclClassDeclList!=null)
            buffer.append(ConstDeclVarDeclClassDeclList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(GlobalVarDecl!=null)
            buffer.append(GlobalVarDecl.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [GlobalDeclarationsGlobalVarDecl]");
        return buffer.toString();
    }
}
