package rs.ac.bg.etf.pp1;

import rs.ac.bg.etf.pp1.CounterVisitor.FormParamCounter;
import rs.ac.bg.etf.pp1.CounterVisitor.VarCounter;
import rs.ac.bg.etf.pp1.ast.*;
import rs.etf.pp1.mj.runtime.Code;
import rs.etf.pp1.symboltable.Tab;
import rs.etf.pp1.symboltable.concepts.*;

public class CodeGenerator extends VisitorAdaptor {
	
	private boolean visitedReturn = false;
	
	private int mainPc;

	public int getMainPc() { return mainPc; }

	SemanticPass sem;

	public CodeGenerator(SemanticPass sem) { this.sem = sem; }

	private int varCount;
	
	private int paramCnt;
	
	//Krecemo!
	
	//TODO: vratiti se na ovo
	public void generateBuiltinFunctionsCode() {
		//rade prakticno istu stvar
		Tab.find("chr").setAdr(Code.pc);
		Tab.find("ord").setAdr(Code.pc);
		//protokol za ulazak u funkciju
		Code.put(Code.enter);
		//primamo jedan parametar
		Code.put(1); 
		//vracamo jedan parametar
		Code.put(1);
		//stavi na stek 0-tu
		Code.put(Code.load_n);
		//protokol za izlaz
		Code.put(Code.exit);
		Code.put(Code.return_);

		Tab.find("len").setAdr(Code.pc);
		Code.put(Code.enter);
		Code.put(1); Code.put(1);
		Code.put(Code.load_n);
		Code.put(Code.arraylength);
		Code.put(Code.exit);
		Code.put(Code.return_);
	}

	public void visit(ProgName progName) {
		generateBuiltinFunctionsCode();
	}

	
	public void visit(CharConstChoose cnst) {
		Code.load(cnst.obj);
	}

	public void visit(BoolConstChoose cnst) {
		Code.load(cnst.obj);
	}

	public void visit(NumConstChoose cnst) {
		Code.load(cnst.obj);
	}
	
	
	
	public void visitMethod(OpeningMethod method, String name) {
		if (name.equals("main")) {
			mainPc = Code.pc;
		}
		method.obj.setAdr(Code.pc);

		Code.put(Code.enter);
		Code.put(sem.allFunctions.get(method.obj.getName()).parCount);
		Code.put(method.obj.getLocalSymbols().size());
	}
	
	//cim naidjem na metodu
	public void visit(OpeningMethod method) {
		visitMethod(method, method.getName());
	}
	
	public void visitMethodDeclarationList(MethodDeclarationList method) {
		Code.put(Code.exit);
		Code.put(Code.return_);
		visitedReturn = false;
	}

	public void visit(MethodDeclarationsTypeFormalParams method) {
		if(!visitedReturn) {
			Code.put(Code.trap);
		}
		visitMethodDeclarationList(method);
	}
	
	public void visit(MethodDeclarationsTypeNoFormalParams method) {
		if(!visitedReturn) {
			Code.put(Code.trap);
			Code.put(-1);
		}
		visitMethodDeclarationList(method);
	}
	
	public void visit(MethodDeclarationsVoidFormalParams method) {
		visitMethodDeclarationList(method);
	}
	
	public void visit(MethodDeclarationsVoidNoFormalParams method) {
		visitMethodDeclarationList(method);
	}
	
	public void visit(ReturnExprStatement stmt) {
		// + na steku je rezultat Expr-a
		Code.put(Code.exit);
		Code.put(Code.return_);
	}

	public void visit(ReturnStatement stmt) {
		visitedReturn = true;
		Code.put(Code.exit);
		Code.put(Code.return_);
	}

	public void visit(ReadStatement stmt) {
		/* 	...
		    ..., arr, index
		    		 */
		Obj obj = stmt.getDesignator().obj;
		if (obj.getType().equals(Tab.charType)) {
			Code.put(Code.bread);
		}
		else {
			Code.put(Code.read);
		}
		Code.store(obj);
	}
	
	public void visit(PrintStatementNormal print) {
		/*
		 * ocekuje stek: ..., val
		 */
		if (print.getExpr().struct.equals(Tab.charType)) {
			Code.loadConst(1);
			Code.put(Code.bprint);
		} else {
			Code.loadConst(5);
			Code.put(Code.print);
		}
	}
	
	public void visit(PrintStatementConst stmt) {
		/*
		 * ocekuje stek: ..., val
		 */
		Code.loadConst(stmt.getN2());
		if (stmt.getExpr().struct.equals(Tab.charType)) {
			Code.put(Code.bprint);
		}
		else {
			Code.put(Code.print);
		}
	}
	
	
	//saljemo obj od designatora, a pozivamo je u factoru i u desig statement
	public void prepareFunctionCall(Obj obj) {
		int offset = obj.getAdr() - Code.pc;
		Code.put(Code.call);
		Code.put2(offset);
	}
	
	public void visit(DesignatorStatementAssignop desig) {
		/*
		  	..., expr
		    ..., arr, indx, expr
		 */
		Code.store(desig.getDesignator().obj);
	}

	public void visit(DesignatorStatementParen desig) {
		
		prepareFunctionCall(desig.getDesignator().obj);
		
		// u slucaju da zovemo funkciju koja vraca vrednost, a ne koristimo tu vrednost nigde u izrazu,
		// popujemo vrednost sa steka
		if (desig.getDesignator().obj.getType() != Tab.noType) {
			Code.put(Code.pop);
		}
	}
	
	public void visit(DesignatorStatementActPars desig) {
		prepareFunctionCall(desig.getDesignator().obj);
		// u slucaju da zovemo funkciju koja vraca vrednost, a ne koristimo tu vrednost nigde u izrazu,
		// popujemo vrednost sa steka
		if (desig.getDesignator().obj.getType() != Tab.noType) {
			Code.put(Code.pop);
		}
	}
	
	public void visit(DesignatorStatementIncrement desig) {
		Code.load(desig.getDesignator().obj);
		Code.put(Code.const_1);
		Code.put(Code.add);
		Code.store(desig.getDesignator().obj);
	}
	
	public void visit(DesignatorStatementDecrement desig) {
		Code.load(desig.getDesignator().obj);
		Code.put(Code.const_m1);
		Code.put(Code.add);
		Code.store(desig.getDesignator().obj);
	}
	
	
	
	public void visit(NormalExpr expr) {
	}

	public void visit(MinusTerm expr) {
		Code.put(Code.neg);
	}

	public void visit(AddopTerms expr) { 
		
		Addop op = expr.getAddop();
		if(op instanceof Plus) {
			Code.put(Code.add);
		}
		else if(op instanceof Minus) {
			Code.put(Code.sub);
		}
	}

	public void visit(MulopFactors term) {
		Mulop op = term.getMulop();
		if (op instanceof Mul) {
			Code.put(Code.mul);
		}
		else if (op instanceof Div) {
			Code.put(Code.div);
		}
		else if (op instanceof Mod) {
			Code.put(Code.rem);
		}
	}

	
	public void visit(DesignatorParen factor) {
		prepareFunctionCall(factor.getDesignator().obj);
	}
	
	public void visit(DesignatorActPars factor) {
		prepareFunctionCall(factor.getDesignator().obj);
	}

	public void visit(NewArray factor) {

		//   ocekuje se stek: ..., n

		Code.put(Code.newarray);
		Code.put(factor.struct.equals(Tab.charType) ? 0 : 1);
	}

	
	
	public void visit(DesignatorName desig) {
		
	}
	public void visit(DesignatorFullName desig) {
		
	}
	
	///vazno!
	public void visit(DesignatorFull desig) {
		SyntaxNode parent = desig.getParent();
		
		//skalar
		if(desig.getDesignatorDotList() instanceof NoDesignatorDots) {
			
			if (parent instanceof DesignatorFactor) {
				// ocekuje se stek: ..., rval
				Code.load(desig.obj);
			}
		}
		//niz
		else if(desig.getDesignatorDotList() instanceof DesignatorDotsArrayNoExpr) {
			if(parent instanceof DesignatorFactor) {
				Code.load(desig.obj);
			}
		}
		
		//ako si array sa indeksiranjem
		else if(desig.getDesignatorDotList() instanceof DesignatorDotsArray) {
			//ako sam te pozvao jer si ti niz sa LEVE strane assignopa.
			if(parent instanceof DesignatorStatementAssignop) {
				int adr = desig.getDesignatorFullName().obj.getAdr();
				if(desig.getDesignatorFullName().obj.getLevel() != 0) 
				{
				Code.put(Code.load);
				Code.put(adr);
				}
			//ako si globalna promenljiva, stavi se na stek preko posebne metode
			else {
			Code.put(Code.getstatic);
			Code.put2(adr);
			}
				//moram da rotiram vrsni deo steka 
				Code.put(Code.dup_x1);
				Code.put(Code.pop);
				// ..., adr, ind
				//i ocekujemo da cemo posle dobiti val
			}
			else if(parent instanceof Factor) {
				int adr = desig.getDesignatorFullName().obj.getAdr();
				if(desig.getDesignatorFullName().obj.getLevel() != 0) 
					{
					Code.put(Code.load);
					Code.put(adr);
					}
				//ako si globalna promenljiva, stavi se na stek preko posebne metode
				else {
				Code.put(Code.getstatic);
				Code.put2(adr);
				}
				//moram da rotiram vrsni deo steka 
				Code.put(Code.dup_x1);
				Code.put(Code.pop);
				//..., adr, ind
				//Code.put(Code.aload);
				if(desig.getDesignatorFullName().obj.getType().getElemType().getKind() == 2) {
					Code.put(Code.baload);
				} else // if (desig.getDesignatorFullName().obj.getType().getElemType().getKind() == 1) {
					{Code.put(Code.aload);
				}
				//Code.load(desig.getDesignatorFullName().obj);
				//..., val
			}
		}
	}
	
	public void visit(DesignatorNormal desig) {
		SyntaxNode parent = desig.getParent();
		
		//skalar
		if(desig.getDesignatorDotList() instanceof NoDesignatorDots) {
			
			if (parent instanceof DesignatorFactor) {
				// ocekuje se stek: ..., rval
				Code.load(desig.obj);
			}
		}
		//niz
		else if(desig.getDesignatorDotList() instanceof DesignatorDotsArrayNoExpr) {
			if(parent instanceof DesignatorFactor) {
				Code.load(desig.obj);
			}
		}
		
		//ako si array sa indeksiranjem
		else if(desig.getDesignatorDotList() instanceof DesignatorDotsArray) {
			//ako sam te pozvao jer si ti niz sa leve strane assignopa.
			if(parent instanceof DesignatorStatementAssignop) {
				int adr = desig.getDesignatorName().obj.getAdr();
				//ako si lokalna promenljiva, samo se stavi na stek
				if(desig.getDesignatorName().obj.getLevel() != 0) 
				{
				Code.put(Code.load);
				Code.put(adr);
				}
			//ako si globalna promenljiva, stavi se na stek preko posebne metode
			else {
			Code.put(Code.getstatic);
			Code.put2(adr);
			}
				//moram da rotiram vrsni deo steka 
				Code.put(Code.dup_x1);
				Code.put(Code.pop);
				// ..., adr, ind
				//i ocekujemo da cemo posle dobiti val
				
			}
			else if(parent instanceof Factor) {
				int adr = desig.getDesignatorName().obj.getAdr();
				if(desig.getDesignatorName().obj.getLevel() != 0) 
				{
				Code.put(Code.load);
				Code.put(adr);
				}
			//ako si globalna promenljiva, stavi se na stek preko posebne metode
			else {
			Code.put(Code.getstatic);
			Code.put2(adr);
			}
				//moram da rotiram vrsni deo steka 
				Code.put(Code.dup_x1);
				Code.put(Code.pop);
				//..., adr, ind
				//Code.put(Code.aload);
				if(desig.getDesignatorName().obj.getType().getElemType().getKind() == 2) {
					Code.put(Code.baload);
				} else //if (desig.getDesignatorName().obj.getType().getElemType().getKind() == 1) {
					{Code.put(Code.aload);
				}
				//..., val
			}
		}
	}
	
	
	
	
	//MulopFactorList
	/*@Override
	public void visit(MethodTypeName MethodTypeName) {
		if ("main".equalsIgnoreCase(MethodTypeName.getMethName())) {
			mainPc = Code.pc;
		}
		MethodTypeName.obj.setAdr(Code.pc);
		
		// Collect arguments and local variables.
		SyntaxNode methodNode = MethodTypeName.getParent();
		VarCounter varCnt = new VarCounter();
		methodNode.traverseTopDown(varCnt);
		FormParamCounter fpCnt = new FormParamCounter();
		methodNode.traverseTopDown(fpCnt);
		
		// Generate the entry.
		Code.put(Code.enter);
		Code.put(fpCnt.getCount());
		Code.put(varCnt.getCount() + fpCnt.getCount());
	}
	
	@Override
	public void visit(VarDecl VarDecl) {
		varCount++;
	}

	@Override
	public void visit(FormalParamDecl FormalParam) {
		paramCnt++;
	}	
	
	@Override
	public void visit(MethodDecl MethodDecl) {
		Code.put(Code.exit);
		Code.put(Code.return_);
	}
	
	@Override
	public void visit(ReturnExpr ReturnExpr) {
		Code.put(Code.exit);
		Code.put(Code.return_);
	}
	
	@Override
	public void visit(ReturnNoExpr ReturnNoExpr) {
		Code.put(Code.exit);
		Code.put(Code.return_);
	}
	
	@Override
	public void visit(Assignment Assignment) {
		Code.store(Assignment.getDesignator().obj);
	}
	
	
	@Override
	public void visit(Designator Designator) {
		SyntaxNode parent = Designator.getParent();
		if (Assignment.class != parent.getClass() && FuncCall.class != parent.getClass()) {
			Code.load(Designator.obj);
		}
	}
	
	@Override
	public void visit(FuncCall FuncCall) {
		Obj functionObj = FuncCall.getDesignator().obj;
		int offset = functionObj.getAdr() - Code.pc; 
		Code.put(Code.call);
		Code.put2(offset);
	}
	
	@Override
	public void visit(PrintStmt PrintStmt) {
		Code.put(Code.const_5);
		Code.put(Code.print);
	}
	
	@Override
	public void visit(AddExpr AddExpr) {
		Code.put(Code.add);
	}*/

}
