// generated with ast extension for cup
// version 0.8
// 13/0/2024 21:45:25


package rs.ac.bg.etf.pp1.ast;

public abstract class VisitorAdaptor implements Visitor { 

    public void visit(Mulop Mulop) { }
    public void visit(Relop Relop) { }
    public void visit(MulopFactorList MulopFactorList) { }
    public void visit(StaticInitializerList StaticInitializerList) { }
    public void visit(MethodDeclarationList MethodDeclarationList) { }
    public void visit(StatementList StatementList) { }
    public void visit(CommaDesignatorStatementList CommaDesignatorStatementList) { }
    public void visit(NamespaceList NamespaceList) { }
    public void visit(DesignatorStatementError DesignatorStatementError) { }
    public void visit(Addop Addop) { }
    public void visit(Factor Factor) { }
    public void visit(VarDeclCommaList VarDeclCommaList) { }
    public void visit(DesignatorCommaList DesignatorCommaList) { }
    public void visit(GlobalVarDecl GlobalVarDecl) { }
    public void visit(Designator Designator) { }
    public void visit(StaticVarDeclList StaticVarDeclList) { }
    public void visit(AndCondFactList AndCondFactList) { }
    public void visit(CommaConstDeclList CommaConstDeclList) { }
    public void visit(DesignatorNiz DesignatorNiz) { }
    public void visit(FormParsCommaList FormParsCommaList) { }
    public void visit(VarDeclList VarDeclList) { }
    public void visit(Expr Expr) { }
    public void visit(OrCondTermList OrCondTermList) { }
    public void visit(DesignatorDotList DesignatorDotList) { }
    public void visit(ConstDeclVarDeclClassDeclList ConstDeclVarDeclClassDeclList) { }
    public void visit(DesignatorStatement DesignatorStatement) { }
    public void visit(Statement Statement) { }
    public void visit(VarDecl VarDecl) { }
    public void visit(Type Type) { }
    public void visit(ClassDecl ClassDecl) { }
    public void visit(StaticInitializer StaticInitializer) { }
    public void visit(CondFact CondFact) { }
    public void visit(CommaExprList CommaExprList) { }
    public void visit(FormPars FormPars) { }
    public void visit(ChooseConst ChooseConst) { }
    public void visit(AddopTermList AddopTermList) { }
    public void visit(Label Label) { visit(); }
    public void visit(NoDesignatorComma NoDesignatorComma) { visit(); }
    public void visit(DesignatorCommasComma DesignatorCommasComma) { visit(); }
    public void visit(DesignatorCommasDesignatorComma DesignatorCommasDesignatorComma) { visit(); }
    public void visit(DesignatorNizDerived1 DesignatorNizDerived1) { visit(); }
    public void visit(DesignatorStatementWeird DesignatorStatementWeird) { visit(); }
    public void visit(DesignatorStatementDecrement DesignatorStatementDecrement) { visit(); }
    public void visit(DesignatorStatementIncrement DesignatorStatementIncrement) { visit(); }
    public void visit(DesignatorStatementActPars DesignatorStatementActPars) { visit(); }
    public void visit(DesignatorStatementParen DesignatorStatementParen) { visit(); }
    public void visit(DesignatorStatementAssignop DesignatorStatementAssignop) { visit(); }
    public void visit(Assignop Assignop) { visit(); }
    public void visit(NoAddopTerms NoAddopTerms) { visit(); }
    public void visit(AddopTerms AddopTerms) { visit(); }
    public void visit(Minus Minus) { visit(); }
    public void visit(Plus Plus) { visit(); }
    public void visit(NoMulopFactors NoMulopFactors) { visit(); }
    public void visit(MulopFactors MulopFactors) { visit(); }
    public void visit(Mul Mul) { visit(); }
    public void visit(Div Div) { visit(); }
    public void visit(Mod Mod) { visit(); }
    public void visit(NoCommaExprs NoCommaExprs) { visit(); }
    public void visit(CommaExprs CommaExprs) { visit(); }
    public void visit(ActPars ActPars) { visit(); }
    public void visit(ParenExprFactor ParenExprFactor) { visit(); }
    public void visit(NewParen NewParen) { visit(); }
    public void visit(NewActPars NewActPars) { visit(); }
    public void visit(NewArray NewArray) { visit(); }
    public void visit(ConstFactor ConstFactor) { visit(); }
    public void visit(DesignatorActPars DesignatorActPars) { visit(); }
    public void visit(DesignatorParen DesignatorParen) { visit(); }
    public void visit(DesignatorFactor DesignatorFactor) { visit(); }
    public void visit(Term Term) { visit(); }
    public void visit(MinusTerm MinusTerm) { visit(); }
    public void visit(NormalExpr NormalExpr) { visit(); }
    public void visit(MinusExpr MinusExpr) { visit(); }
    public void visit(DesignatorFullName DesignatorFullName) { visit(); }
    public void visit(DesignatorName DesignatorName) { visit(); }
    public void visit(NoDesignatorDots NoDesignatorDots) { visit(); }
    public void visit(DesignatorDotsArrayNoExpr DesignatorDotsArrayNoExpr) { visit(); }
    public void visit(DesignatorDotsArray DesignatorDotsArray) { visit(); }
    public void visit(DesignatorDotsNormal DesignatorDotsNormal) { visit(); }
    public void visit(DesignatorNormal DesignatorNormal) { visit(); }
    public void visit(DesignatorFull DesignatorFull) { visit(); }
    public void visit(LessEqual LessEqual) { visit(); }
    public void visit(LessThan LessThan) { visit(); }
    public void visit(GreaterEqual GreaterEqual) { visit(); }
    public void visit(GreaterThan GreaterThan) { visit(); }
    public void visit(NEqual NEqual) { visit(); }
    public void visit(Equals Equals) { visit(); }
    public void visit(ExprRelopExproCondFact ExprRelopExproCondFact) { visit(); }
    public void visit(ExprCondFact ExprCondFact) { visit(); }
    public void visit(NoAndCondFacts NoAndCondFacts) { visit(); }
    public void visit(AndCondFacts AndCondFacts) { visit(); }
    public void visit(CondTerm CondTerm) { visit(); }
    public void visit(NoOrCondTerms NoOrCondTerms) { visit(); }
    public void visit(OrCondTerms OrCondTerms) { visit(); }
    public void visit(Condition Condition) { visit(); }
    public void visit(NoCommaDesignatorStatements NoCommaDesignatorStatements) { visit(); }
    public void visit(CommaDesignatorStatements CommaDesignatorStatements) { visit(); }
    public void visit(StatementsInBrace StatementsInBrace) { visit(); }
    public void visit(ForThereThereThere ForThereThereThere) { visit(); }
    public void visit(ForNothingThereThere ForNothingThereThere) { visit(); }
    public void visit(ForThereNothingThere ForThereNothingThere) { visit(); }
    public void visit(ForThereThereNothing ForThereThereNothing) { visit(); }
    public void visit(ForNothingNothingThere ForNothingNothingThere) { visit(); }
    public void visit(ForNothingThereNothing ForNothingThereNothing) { visit(); }
    public void visit(ForThereNothingNothing ForThereNothingNothing) { visit(); }
    public void visit(ForNothingNothingNothing ForNothingNothingNothing) { visit(); }
    public void visit(PrintStatementConst PrintStatementConst) { visit(); }
    public void visit(PrintStatementNormal PrintStatementNormal) { visit(); }
    public void visit(ReadStatement ReadStatement) { visit(); }
    public void visit(ReturnExprStatement ReturnExprStatement) { visit(); }
    public void visit(ReturnStatement ReturnStatement) { visit(); }
    public void visit(ContinueStatement ContinueStatement) { visit(); }
    public void visit(BreakStatement BreakStatement) { visit(); }
    public void visit(IfConditionElse IfConditionElse) { visit(); }
    public void visit(IfCondition IfCondition) { visit(); }
    public void visit(DesignatorStatementErrorStatement DesignatorStatementErrorStatement) { visit(); }
    public void visit(DesignatorStatementErrorDerived1 DesignatorStatementErrorDerived1) { visit(); }
    public void visit(DesignatorStatementSemi DesignatorStatementSemi) { visit(); }
    public void visit(NoStatements NoStatements) { visit(); }
    public void visit(Statements Statements) { visit(); }
    public void visit(ResetTypeMethod ResetTypeMethod) { visit(); }
    public void visit(OpeningMethod OpeningMethod) { visit(); }
    public void visit(NoMethodDeclarations NoMethodDeclarations) { visit(); }
    public void visit(MethodDeclarationsVoidNoFormalParams MethodDeclarationsVoidNoFormalParams) { visit(); }
    public void visit(MethodDeclarationsVoidFormalParams MethodDeclarationsVoidFormalParams) { visit(); }
    public void visit(MethodDeclarationsTypeNoFormalParams MethodDeclarationsTypeNoFormalParams) { visit(); }
    public void visit(MethodDeclarationsTypeFormalParams MethodDeclarationsTypeFormalParams) { visit(); }
    public void visit(NoFormParsComma NoFormParsComma) { visit(); }
    public void visit(FormParsArrayNormal FormParsArrayNormal) { visit(); }
    public void visit(FormParsCommaNormal FormParsCommaNormal) { visit(); }
    public void visit(NormalFormPars NormalFormPars) { visit(); }
    public void visit(ArrayFormPars ArrayFormPars) { visit(); }
    public void visit(NoVarDeclComma NoVarDeclComma) { visit(); }
    public void visit(VarDeclCommaNormal VarDeclCommaNormal) { visit(); }
    public void visit(VarDeclCommaArray VarDeclCommaArray) { visit(); }
    public void visit(NoVarDecls NoVarDecls) { visit(); }
    public void visit(VarDecls VarDecls) { visit(); }
    public void visit(NormalVarDecl NormalVarDecl) { visit(); }
    public void visit(ArrayVarDecl ArrayVarDecl) { visit(); }
    public void visit(GlobalVarDeclDerived2 GlobalVarDeclDerived2) { visit(); }
    public void visit(GlobalVarDeclDerived1 GlobalVarDeclDerived1) { visit(); }
    public void visit(GlobalVarDeclaration GlobalVarDeclaration) { visit(); }
    public void visit(NoCommaConstDecls NoCommaConstDecls) { visit(); }
    public void visit(CommaConstDecls CommaConstDecls) { visit(); }
    public void visit(CharConstChoose CharConstChoose) { visit(); }
    public void visit(NumConstChoose NumConstChoose) { visit(); }
    public void visit(BoolConstChoose BoolConstChoose) { visit(); }
    public void visit(NormalType NormalType) { visit(); }
    public void visit(FullType FullType) { visit(); }
    public void visit(ConstDecl ConstDecl) { visit(); }
    public void visit(StaticInitializerDerived1 StaticInitializerDerived1) { visit(); }
    public void visit(StaticInitializerListDerived2 StaticInitializerListDerived2) { visit(); }
    public void visit(StaticInitializerListDerived1 StaticInitializerListDerived1) { visit(); }
    public void visit(StaticVarDeclListDerived2 StaticVarDeclListDerived2) { visit(); }
    public void visit(StaticVarDeclListDerived1 StaticVarDeclListDerived1) { visit(); }
    public void visit(ClassDeclDerived4 ClassDeclDerived4) { visit(); }
    public void visit(ClassDeclDerived3 ClassDeclDerived3) { visit(); }
    public void visit(ClassDeclDerived2 ClassDeclDerived2) { visit(); }
    public void visit(ClassDeclDerived1 ClassDeclDerived1) { visit(); }
    public void visit(NoGlobalDelcarations NoGlobalDelcarations) { visit(); }
    public void visit(GlobalDeclarationsGlobalVarDecl GlobalDeclarationsGlobalVarDecl) { visit(); }
    public void visit(GlobalDeclarationsConstDecl GlobalDeclarationsConstDecl) { visit(); }
    public void visit(OpenNamespace OpenNamespace) { visit(); }
    public void visit(NoNamespaces NoNamespaces) { visit(); }
    public void visit(Namespaces Namespaces) { visit(); }
    public void visit(ProgName ProgName) { visit(); }
    public void visit(Program Program) { visit(); }


    public void visit() { }
}
