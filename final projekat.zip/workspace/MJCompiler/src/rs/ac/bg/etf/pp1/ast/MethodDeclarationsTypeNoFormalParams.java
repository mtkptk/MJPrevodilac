// generated with ast extension for cup
// version 0.8
// 13/0/2024 21:45:25


package rs.ac.bg.etf.pp1.ast;

public class MethodDeclarationsTypeNoFormalParams extends MethodDeclarationList {

    private MethodDeclarationList MethodDeclarationList;
    private ResetTypeMethod ResetTypeMethod;
    private Type Type;
    private OpeningMethod OpeningMethod;
    private VarDeclList VarDeclList;
    private StatementList StatementList;

    public MethodDeclarationsTypeNoFormalParams (MethodDeclarationList MethodDeclarationList, ResetTypeMethod ResetTypeMethod, Type Type, OpeningMethod OpeningMethod, VarDeclList VarDeclList, StatementList StatementList) {
        this.MethodDeclarationList=MethodDeclarationList;
        if(MethodDeclarationList!=null) MethodDeclarationList.setParent(this);
        this.ResetTypeMethod=ResetTypeMethod;
        if(ResetTypeMethod!=null) ResetTypeMethod.setParent(this);
        this.Type=Type;
        if(Type!=null) Type.setParent(this);
        this.OpeningMethod=OpeningMethod;
        if(OpeningMethod!=null) OpeningMethod.setParent(this);
        this.VarDeclList=VarDeclList;
        if(VarDeclList!=null) VarDeclList.setParent(this);
        this.StatementList=StatementList;
        if(StatementList!=null) StatementList.setParent(this);
    }

    public MethodDeclarationList getMethodDeclarationList() {
        return MethodDeclarationList;
    }

    public void setMethodDeclarationList(MethodDeclarationList MethodDeclarationList) {
        this.MethodDeclarationList=MethodDeclarationList;
    }

    public ResetTypeMethod getResetTypeMethod() {
        return ResetTypeMethod;
    }

    public void setResetTypeMethod(ResetTypeMethod ResetTypeMethod) {
        this.ResetTypeMethod=ResetTypeMethod;
    }

    public Type getType() {
        return Type;
    }

    public void setType(Type Type) {
        this.Type=Type;
    }

    public OpeningMethod getOpeningMethod() {
        return OpeningMethod;
    }

    public void setOpeningMethod(OpeningMethod OpeningMethod) {
        this.OpeningMethod=OpeningMethod;
    }

    public VarDeclList getVarDeclList() {
        return VarDeclList;
    }

    public void setVarDeclList(VarDeclList VarDeclList) {
        this.VarDeclList=VarDeclList;
    }

    public StatementList getStatementList() {
        return StatementList;
    }

    public void setStatementList(StatementList StatementList) {
        this.StatementList=StatementList;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(MethodDeclarationList!=null) MethodDeclarationList.accept(visitor);
        if(ResetTypeMethod!=null) ResetTypeMethod.accept(visitor);
        if(Type!=null) Type.accept(visitor);
        if(OpeningMethod!=null) OpeningMethod.accept(visitor);
        if(VarDeclList!=null) VarDeclList.accept(visitor);
        if(StatementList!=null) StatementList.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(MethodDeclarationList!=null) MethodDeclarationList.traverseTopDown(visitor);
        if(ResetTypeMethod!=null) ResetTypeMethod.traverseTopDown(visitor);
        if(Type!=null) Type.traverseTopDown(visitor);
        if(OpeningMethod!=null) OpeningMethod.traverseTopDown(visitor);
        if(VarDeclList!=null) VarDeclList.traverseTopDown(visitor);
        if(StatementList!=null) StatementList.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(MethodDeclarationList!=null) MethodDeclarationList.traverseBottomUp(visitor);
        if(ResetTypeMethod!=null) ResetTypeMethod.traverseBottomUp(visitor);
        if(Type!=null) Type.traverseBottomUp(visitor);
        if(OpeningMethod!=null) OpeningMethod.traverseBottomUp(visitor);
        if(VarDeclList!=null) VarDeclList.traverseBottomUp(visitor);
        if(StatementList!=null) StatementList.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("MethodDeclarationsTypeNoFormalParams(\n");

        if(MethodDeclarationList!=null)
            buffer.append(MethodDeclarationList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(ResetTypeMethod!=null)
            buffer.append(ResetTypeMethod.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(Type!=null)
            buffer.append(Type.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(OpeningMethod!=null)
            buffer.append(OpeningMethod.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(VarDeclList!=null)
            buffer.append(VarDeclList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(StatementList!=null)
            buffer.append(StatementList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [MethodDeclarationsTypeNoFormalParams]");
        return buffer.toString();
    }
}
