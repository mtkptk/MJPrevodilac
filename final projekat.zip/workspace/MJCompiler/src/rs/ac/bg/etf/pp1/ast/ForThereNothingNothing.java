// generated with ast extension for cup
// version 0.8
// 13/0/2024 21:45:25


package rs.ac.bg.etf.pp1.ast;

public class ForThereNothingNothing extends Statement {

    private DesignatorStatement DesignatorStatement;
    private CommaDesignatorStatementList CommaDesignatorStatementList;

    public ForThereNothingNothing (DesignatorStatement DesignatorStatement, CommaDesignatorStatementList CommaDesignatorStatementList) {
        this.DesignatorStatement=DesignatorStatement;
        if(DesignatorStatement!=null) DesignatorStatement.setParent(this);
        this.CommaDesignatorStatementList=CommaDesignatorStatementList;
        if(CommaDesignatorStatementList!=null) CommaDesignatorStatementList.setParent(this);
    }

    public DesignatorStatement getDesignatorStatement() {
        return DesignatorStatement;
    }

    public void setDesignatorStatement(DesignatorStatement DesignatorStatement) {
        this.DesignatorStatement=DesignatorStatement;
    }

    public CommaDesignatorStatementList getCommaDesignatorStatementList() {
        return CommaDesignatorStatementList;
    }

    public void setCommaDesignatorStatementList(CommaDesignatorStatementList CommaDesignatorStatementList) {
        this.CommaDesignatorStatementList=CommaDesignatorStatementList;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(DesignatorStatement!=null) DesignatorStatement.accept(visitor);
        if(CommaDesignatorStatementList!=null) CommaDesignatorStatementList.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(DesignatorStatement!=null) DesignatorStatement.traverseTopDown(visitor);
        if(CommaDesignatorStatementList!=null) CommaDesignatorStatementList.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(DesignatorStatement!=null) DesignatorStatement.traverseBottomUp(visitor);
        if(CommaDesignatorStatementList!=null) CommaDesignatorStatementList.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("ForThereNothingNothing(\n");

        if(DesignatorStatement!=null)
            buffer.append(DesignatorStatement.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(CommaDesignatorStatementList!=null)
            buffer.append(CommaDesignatorStatementList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [ForThereNothingNothing]");
        return buffer.toString();
    }
}
