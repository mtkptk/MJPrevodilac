// generated with ast extension for cup
// version 0.8
// 13/0/2024 21:45:25


package rs.ac.bg.etf.pp1.ast;

public class CommaConstDecls extends CommaConstDeclList {

    private CommaConstDeclList CommaConstDeclList;
    private String name;
    private ChooseConst ChooseConst;

    public CommaConstDecls (CommaConstDeclList CommaConstDeclList, String name, ChooseConst ChooseConst) {
        this.CommaConstDeclList=CommaConstDeclList;
        if(CommaConstDeclList!=null) CommaConstDeclList.setParent(this);
        this.name=name;
        this.ChooseConst=ChooseConst;
        if(ChooseConst!=null) ChooseConst.setParent(this);
    }

    public CommaConstDeclList getCommaConstDeclList() {
        return CommaConstDeclList;
    }

    public void setCommaConstDeclList(CommaConstDeclList CommaConstDeclList) {
        this.CommaConstDeclList=CommaConstDeclList;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name=name;
    }

    public ChooseConst getChooseConst() {
        return ChooseConst;
    }

    public void setChooseConst(ChooseConst ChooseConst) {
        this.ChooseConst=ChooseConst;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(CommaConstDeclList!=null) CommaConstDeclList.accept(visitor);
        if(ChooseConst!=null) ChooseConst.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(CommaConstDeclList!=null) CommaConstDeclList.traverseTopDown(visitor);
        if(ChooseConst!=null) ChooseConst.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(CommaConstDeclList!=null) CommaConstDeclList.traverseBottomUp(visitor);
        if(ChooseConst!=null) ChooseConst.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("CommaConstDecls(\n");

        if(CommaConstDeclList!=null)
            buffer.append(CommaConstDeclList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(" "+tab+name);
        buffer.append("\n");

        if(ChooseConst!=null)
            buffer.append(ChooseConst.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [CommaConstDecls]");
        return buffer.toString();
    }
}
