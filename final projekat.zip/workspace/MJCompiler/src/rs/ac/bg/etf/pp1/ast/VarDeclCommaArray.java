// generated with ast extension for cup
// version 0.8
// 13/0/2024 21:45:25


package rs.ac.bg.etf.pp1.ast;

public class VarDeclCommaArray extends VarDeclCommaList {

    private VarDeclCommaList VarDeclCommaList;
    private String name;

    public VarDeclCommaArray (VarDeclCommaList VarDeclCommaList, String name) {
        this.VarDeclCommaList=VarDeclCommaList;
        if(VarDeclCommaList!=null) VarDeclCommaList.setParent(this);
        this.name=name;
    }

    public VarDeclCommaList getVarDeclCommaList() {
        return VarDeclCommaList;
    }

    public void setVarDeclCommaList(VarDeclCommaList VarDeclCommaList) {
        this.VarDeclCommaList=VarDeclCommaList;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name=name;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(VarDeclCommaList!=null) VarDeclCommaList.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(VarDeclCommaList!=null) VarDeclCommaList.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(VarDeclCommaList!=null) VarDeclCommaList.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("VarDeclCommaArray(\n");

        if(VarDeclCommaList!=null)
            buffer.append(VarDeclCommaList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(" "+tab+name);
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [VarDeclCommaArray]");
        return buffer.toString();
    }
}
