// generated with ast extension for cup
// version 0.8
// 13/0/2024 21:45:25


package rs.ac.bg.etf.pp1.ast;

public class DesignatorStatementErrorStatement extends Statement {

    private DesignatorStatementError DesignatorStatementError;

    public DesignatorStatementErrorStatement (DesignatorStatementError DesignatorStatementError) {
        this.DesignatorStatementError=DesignatorStatementError;
        if(DesignatorStatementError!=null) DesignatorStatementError.setParent(this);
    }

    public DesignatorStatementError getDesignatorStatementError() {
        return DesignatorStatementError;
    }

    public void setDesignatorStatementError(DesignatorStatementError DesignatorStatementError) {
        this.DesignatorStatementError=DesignatorStatementError;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(DesignatorStatementError!=null) DesignatorStatementError.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(DesignatorStatementError!=null) DesignatorStatementError.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(DesignatorStatementError!=null) DesignatorStatementError.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("DesignatorStatementErrorStatement(\n");

        if(DesignatorStatementError!=null)
            buffer.append(DesignatorStatementError.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [DesignatorStatementErrorStatement]");
        return buffer.toString();
    }
}
