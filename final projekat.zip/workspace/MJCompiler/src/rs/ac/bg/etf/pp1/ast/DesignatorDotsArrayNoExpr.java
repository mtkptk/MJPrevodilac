// generated with ast extension for cup
// version 0.8
// 13/0/2024 21:45:25


package rs.ac.bg.etf.pp1.ast;

public class DesignatorDotsArrayNoExpr extends DesignatorDotList {

    private DesignatorDotList DesignatorDotList;

    public DesignatorDotsArrayNoExpr (DesignatorDotList DesignatorDotList) {
        this.DesignatorDotList=DesignatorDotList;
        if(DesignatorDotList!=null) DesignatorDotList.setParent(this);
    }

    public DesignatorDotList getDesignatorDotList() {
        return DesignatorDotList;
    }

    public void setDesignatorDotList(DesignatorDotList DesignatorDotList) {
        this.DesignatorDotList=DesignatorDotList;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(DesignatorDotList!=null) DesignatorDotList.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(DesignatorDotList!=null) DesignatorDotList.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(DesignatorDotList!=null) DesignatorDotList.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("DesignatorDotsArrayNoExpr(\n");

        if(DesignatorDotList!=null)
            buffer.append(DesignatorDotList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [DesignatorDotsArrayNoExpr]");
        return buffer.toString();
    }
}
