package rs.ac.bg.etf.pp1;
import org.apache.log4j.Logger;
import java.util.*;

import rs.ac.bg.etf.pp1.ast.Designator;
import rs.ac.bg.etf.pp1.ast.NormalType;
import rs.ac.bg.etf.pp1.ast.ProgName;
import rs.ac.bg.etf.pp1.ast.Program;
import rs.ac.bg.etf.pp1.ast.SyntaxNode;
import rs.ac.bg.etf.pp1.ast.Term;
import rs.ac.bg.etf.pp1.ast.*;
import rs.ac.bg.etf.pp1.ast.VarDecl;
import rs.ac.bg.etf.pp1.ast.VisitorAdaptor;
import rs.etf.pp1.symboltable.Tab;
import rs.etf.pp1.symboltable.concepts.Obj;
import rs.etf.pp1.symboltable.concepts.Struct;

public class SemanticPass extends VisitorAdaptor {

	//TODO: izdvojiti na poseban nacin globalne promenljive. Done.
	
	private Struct declarationType = null;
	private Struct returnType = Tab.noType;
	
	boolean errorDetected = false;
	int printCallCount = 0;
	Obj currentMethod = null;
	boolean returnFound = false;
	int nVars;
	int loopCount = 0;
	
	String currNamespace = "";
	boolean namespaceOpen = false;
	
	HashMap<String, FunctionData> allFunctions = new HashMap<>();
	Stack<ArrayList<Struct>> funStack = new Stack<>();
	
	Logger log = Logger.getLogger(getClass());
	
	Struct constType = null;
	
	public static Struct booleanType = Tab.insert(Obj.Type, "bool", new Struct(Struct.Bool)).getType();

	//podaci o funkcijama
	class FunctionData {
		//broj parametara
		public int parCount = 0;
		public ArrayList<Struct> arguments = new ArrayList<>();

		public FunctionData() {}

		public FunctionData(Struct s) {
			insert(s);
		}

		public void insert(Struct s) {
			parCount++;
			arguments.add(s);
		}

		public String toString() {
			String s = "";
			for (int i = 0; i < arguments.size(); i++) {
				s += "" + (i+1) + ": " + structToString(arguments.get(i)) + '\n';
			}
			return s.equals("") ?
					"nema formalnih parametara\n" :
					s;
		}
	}
	
	/*class Namespaces {
		public String name;
		public ArrayList<SyntaxNode> names = new ArrayList<SyntaxNode>();
	}*/
	
	public static String structToString(Struct s) {
		String suffix = "";
		if (s.getKind() == Struct.Array) {
			s = s.getElemType();
			suffix += "[]";
		}

		switch(s.getKind()) {
		case 0:	return "void"+suffix;
		case 1: return "int"+suffix;
		case 2: return "char"+suffix;
		case 3: return "array"+suffix;
		case 4: return "class"+suffix;
		case 5: return "bool"+suffix;
		default: return "error"+suffix;

		}
	}
	
	public void report_error(String message, SyntaxNode info) {
		errorDetected = true;
		StringBuilder msg = new StringBuilder(message);
		int line = (info == null) ? 0: info.getLine();
		if (line != 0)
			msg.append (" na liniji ").append(line);
		log.error(msg.toString());
	}

	public void report_info(String message, SyntaxNode info) {
		StringBuilder msg = new StringBuilder(message); 
		int line = (info == null) ? 0: info.getLine();
		if (line != 0)
			msg.append (" na liniji ").append(line);
		log.info(msg.toString());
	}
	
	//pozvati odmah da bi se ugradile u tabelu simbola
	public void addBuiltInFunctions() {
		FunctionData chr = new FunctionData(Tab.intType);
		FunctionData ord = new FunctionData(Tab.charType);
		FunctionData len = new FunctionData(Tab.noType);
		allFunctions.put("chr", chr);
		allFunctions.put("ord", ord);
		allFunctions.put("len", len);
	}
	
	public void visit(Program program) {
		if(allFunctions.get("main") == null) {
			report_error("mora postojati main funkcija.", null);
		}
		nVars = Tab.currentScope.getnVars();
		Tab.chainLocalSymbols(program.getProgName().obj);
		Tab.closeScope();
	}

	public void visit(ProgName progName) {
		addBuiltInFunctions();
		progName.obj = Tab.insert(Obj.Prog, progName.getProgName(), Tab.noType);
		Tab.openScope();
		report_info("===================Semantika=================", null);
	}

	
	public void visit(NormalType type) {
		Obj typeNode = Tab.find(type.getTypeName());
		type.struct = Tab.noType;
		declarationType = Tab.noType;

		
		if (typeNode == Tab.noObj) {
			report_error("Ne postoji tip [" + type.getTypeName() + ']', null);
			return;
		}

		if (typeNode.getKind() != Obj.Type) {
			report_error("Ne postoji tip 2 [" + type.getTypeName() + ']', null);
			return;
		}

		declarationType = type.struct = typeNode.getType();
	}
	
	public void visit(NumConstChoose cnst) {
		cnst.obj = new Obj(Obj.Con, "", Tab.intType, cnst.getN1(), 0);
		constType = Tab.intType;
	}
	
	public void visit(CharConstChoose cnst) {
		cnst.obj = new Obj(Obj.Con, "", Tab.charType, cnst.getC1(), 0);
		constType = Tab.charType;
	}
	
	public void visit(BoolConstChoose cnst) {
		cnst.obj = new Obj(Obj.Con, "", booleanType, cnst.getB1()?1:0, 0);
		constType = booleanType;
	}
	
	//iste, samo kopirano. Ova prva omogucava smenu poslednje navedene konstante
	public void visit(ConstDecl cdecl) {
		String name = cdecl.getName();
		
		if(namespaceOpen) {
			//puno ime smestamo u tabelu
			name = currNamespace + name;
		}
		
		//pogledaj postoji li vec ime u tabeli
		if (Tab.find(name) != Tab.noObj) {
			report_error("konstanta " + name + " je vec deklarisana", cdecl);
			return;
		}

		//poklapaju li se tipovi?
		if (!cdecl.getChooseConst().obj.getType().assignableTo(declarationType)) {
			report_error("tip konstante [" + name + "] i deklaracija se ne poklapaju", cdecl);
			return;
		}

		//Obj obj = Tab.insert(Obj.Con, cdecl.getName(), declarationType);
		Obj obj = Tab.insert(Obj.Con, name, declarationType);
		Obj kid = cdecl.getChooseConst().obj;
		obj.setAdr(kid.getAdr());
		obj.setLevel(0);
		report_info("konstanta [" + name + "] definisana", cdecl);
	}
	
	public void visit(CommaConstDecls cdecl) {
		String name = cdecl.getName();
		
		if(namespaceOpen) {
			//puno ime smestamo u tabelu
			name = currNamespace + name;
		}
		
		//pogledaj postoji li vec ime u tabeli
		if (Tab.find(name) != Tab.noObj) {
			report_error("konstanta " + name + " je vec deklarisana", cdecl);
			return;
		}

		//poklapaju li se tipovi?
		if (!cdecl.getChooseConst().obj.getType().assignableTo(declarationType)) {
			report_error("tip konstante [" + name + "] i deklaracija se ne poklapaju", cdecl);
			return;
		}

		//Obj obj = Tab.insert(Obj.Con, cdecl.getName(), declarationType);
		Obj obj = Tab.insert(Obj.Con, name, declarationType);
		Obj kid = cdecl.getChooseConst().obj;
		obj.setAdr(kid.getAdr());
		obj.setLevel(0);
		report_info("konstanta [" + name + "] definisana", cdecl);
	}
	

	
	//samo copy paste, bilo bi pametno da se uvede jedna metoda za sve sa vardecl...
	public void visit(ArrayVarDecl var) {

		String name = var.getName();
		if(namespaceOpen) {
			//puno ime smestamo u tabelu
			name = currNamespace + name;
		}
		
		if (Tab.currentScope.findSymbol(name) != null) {
			report_error("simbol [" + name + "] vec postoji u trenutnom scopeu", var);
			return;
		}

		Obj obj = Tab.insert(Obj.Var, name, new Struct(Struct.Array, declarationType));
		if(obj.getLevel() == 0) {
			report_info("globalna nizovska promenljiva [" + name + "] deklarisana", var);
			return;
		}
		report_info("niz [" + name + "] deklarisan", var);
	}
	
	public void visit(NormalVarDecl var) {
		String name = var.getName();
		if(namespaceOpen) {
			//puno ime smestamo u tabelu
			name = currNamespace + name;
		}
		
		
		if (Tab.currentScope.findSymbol(name) != null) {
			report_error("simbol [" + name + "] vec postoji u trenutnom scopeu", var);
			return;
		}

		Obj obj = Tab.insert(Obj.Var, name, declarationType);
		if(obj.getLevel() == 0) {
			report_info("globalna promenljiva [" + name + "] deklarisana", var);
			return;
		}
		report_info("promenljiva [" + name + "] deklarisana", var);
	}
	
	public void visit(VarDeclCommaArray var) {
		String name = var.getName();
		if(namespaceOpen) {
			//puno ime smestamo u tabelu
			name = currNamespace + name;
		}
		
		if (Tab.currentScope.findSymbol(name) != null) {
			report_error("simbol [" + name + "] vec postoji u trenutnom scopeu", var);
			return;
		}

		 Obj obj = Tab.insert(Obj.Var, name, new Struct(Struct.Array, declarationType));
			if(obj.getLevel() == 0) {
				report_info("globalna nizovska promenljiva [" + name + "] deklarisana", var);
				return;
			}
		 report_info("niz [" + name + "] deklarisan", var);
	}
	
	public void visit(VarDeclCommaNormal var) {
		String name = var.getName();
		if(namespaceOpen) {
			//puno ime smestamo u tabelu
			name = currNamespace + name;
		}
		
		if (Tab.currentScope.findSymbol(name) != null) {
			report_error("simbol [" + name + "] vec postoji u trenutnom scopeu", var);
			return;
		}

		Obj obj = Tab.insert(Obj.Var, name, declarationType);
		if(obj.getLevel() == 0) {
			report_info("globalna promenljiva [" + name + "] deklarisana", var);
			return;
		}
		report_info("Promenljiva [" + name + "] deklarisana", var);
	}
	
	
	
	
	
	public void visit(NormalFormPars form) {
		String name = form.getName();
		
		if (Tab.currentScope.findSymbol(name) != null) {
			report_error("simbol [" + name + "] vec postoji u trenutnom scopeu", form);
			return;
		}
		
		Tab.insert(Obj.Var, name, form.getType().struct);
		report_info("formpar normalan [" + name + "] deklarisan", form);

		FunctionData fd = allFunctions.get(currentMethod.getName());
		fd.insert(form.getType().struct);
		
	}

	public void visit(FormParsCommaNormal form) {
		String name = form.getName();
		
		if (Tab.currentScope.findSymbol(name) != null) {
			report_error("simbol [" + name + "] vec postoji u trenutnom scope-u", form);
			return;
		}
		
		Tab.insert(Obj.Var, name, form.getType().struct);
		report_info("formpar normalan [" + name + "] deklarisan", form);

		FunctionData fd = allFunctions.get(currentMethod.getName());
		fd.insert(form.getType().struct);
	}
	
	public void visit(ArrayFormPars form) {
		String name = form.getName();
		
		if (Tab.currentScope.findSymbol(name) != null) {
			report_error("simbol [" + name + "] vec postoji u trenutnom scope-u", form);
			return;
		}
		
		Tab.insert(Obj.Var, name, new Struct(Struct.Array, form.getType().struct));
		report_info("formpar normalan [" + name + "] deklarisan", form);

		FunctionData fd = allFunctions.get(currentMethod.getName());
		fd.insert(form.getType().struct);
	}
	
	public void visit(FormParsArrayNormal form) {
		String name = form.getName();
		
		if (Tab.currentScope.findSymbol(name) != null) {
			report_error("simbol [" + name + "] vec postoji u trenutnom scope-u", form);
			return;
		}
		
		Tab.insert(Obj.Var, name, new Struct(Struct.Array, form.getType().struct));
		report_info("formpar normalan [" + name + "] deklarisan", form);

		FunctionData fd = allFunctions.get(currentMethod.getName());
		fd.insert(form.getType().struct);
	}
	
	//misli se na deklaraciju metode
	public void visit(OpeningMethod method) {
		
		String name = method.getName();
		
		if(namespaceOpen) {
			//puno ime smestamo u tabelu
			name = currNamespace + name;
		}
		
		if (Tab.currentScope.findSymbol(name) != null) {
			report_error("metoda [" + name + "] je vec definisana", method);
			return;
		}
		
		method.obj = currentMethod = Tab.insert(Obj.Meth, name, declarationType);
		//ubacujem metodu u svoju evidenciju
		allFunctions.put(name, new FunctionData());
		returnType = declarationType;
		//otvaramo novi scope!!!!
		Tab.openScope();
		
	}
	
	public void visit(MethodDeclarationsTypeFormalParams method) {
		String name = currentMethod.getName();
		Struct type = currentMethod.getType();

		if (name.equals("main")) {
			ArrayList<Struct> arguments = (ArrayList<Struct>) allFunctions.get(name).arguments;
			if (type != Tab.noType) {
				report_error(String.format("metoda [main] mora biti tipa VOID"), method);
			}
			if (arguments.size() > 0) {
				report_error("metoda [main] je bez argumenata", method);
			}
		}
		if (returnType != type) {
			report_error(String.format("tip povratne vrednosti (%s) se ne poklapa sa tipom (%s) funkcije [%s]",
					structToString(returnType), structToString(type), name), method);
		}

		Tab.chainLocalSymbols(currentMethod);
		Tab.closeScope();

		currentMethod = null;
		returnType = Tab.noType;
	}
	
	public void visit(MethodDeclarationsTypeNoFormalParams method) {
		String name = currentMethod.getName();
		Struct type = currentMethod.getType();

		if (name.equals("main")) {
			ArrayList<Struct> arguments = (ArrayList<Struct>) allFunctions.get(name).arguments;
			if (type != Tab.noType) {
				report_error(String.format("metoda [main] mora biti tipa VOID"), method);
			}
			if (arguments.size() > 0) {
				report_error("metoda [main] je bez argumenata", method);
			}
		}
		if (returnType != type) {
			report_error(String.format("tip povratne vrednosti (%s) se ne poklapa sa tipom (%s) funkcije [%s]",
					structToString(returnType), structToString(type), name), method);
		}

		Tab.chainLocalSymbols(currentMethod);
		Tab.closeScope();

		currentMethod = null;
		returnType = Tab.noType;
	}
	
	public void visit(MethodDeclarationsVoidFormalParams method) {
		String name = currentMethod.getName();
		Struct type = currentMethod.getType();

		if (name.equals("main")) {
			ArrayList<Struct> arguments = (ArrayList<Struct>) allFunctions.get(name).arguments;
			if (type != Tab.noType) {
				report_error(String.format("metoda [main] mora biti tipa VOID"), method);
			}
			if (arguments.size() > 0) {
				report_error("metoda [main] je bez argumenata", method);
			}
		}
		if (returnType != type) {
			report_error(String.format("tip povratne vrednosti (%s) se ne poklapa sa tipom (%s) funkcije [%s]",
					structToString(returnType), structToString(type), name), method);
		}

		Tab.chainLocalSymbols(currentMethod);
		Tab.closeScope();

		currentMethod = null;
		returnType = Tab.noType;
	}
	
	public void visit(MethodDeclarationsVoidNoFormalParams method) {
		String name = currentMethod.getName();
		Struct type = currentMethod.getType();

		if (name.equals("main")) {
			ArrayList<Struct> arguments = (ArrayList<Struct>) allFunctions.get(name).arguments;
			if (type != Tab.noType) {
				report_error(String.format("metoda [main] mora biti tipa VOID"), method);
			}
			if (arguments.size() > 0) {
				report_error("metoda [main] je bez argumenata", method);
			}
		}
		if (returnType != type) {
			report_error(String.format("tip povratne vrednosti (%s) se ne poklapa sa tipom (%s) funkcije [%s]",
					structToString(returnType), structToString(type), name), method);
		}

		Tab.chainLocalSymbols(currentMethod);
		Tab.closeScope();

		currentMethod = null;
		returnType = Tab.noType;
	}

	public void visit(ResetTypeMethod rst) {
		declarationType = Tab.noType;
	}
	
	
	
	public void visit(NormalExpr expr) {
		
		// Expr --> Term;
		//proveriti koja je klasa u pitanju?
		if(expr.getAddopTermList() instanceof NoAddopTerms) {
			expr.struct = expr.getTerm().struct;
			return;
		}
		
		
		if (expr.getTerm().struct != Tab.intType) {
			report_error("Term za expr mora biti tipa int", expr);
			expr.struct = Tab.noType;
			return;
		}
				
		expr.struct = Tab.intType;
	}

	public void visit(MinusTerm expr) {
		if (expr.getTerm().struct != Tab.intType) {
			report_error("Term za expr mora biti tipa int", expr);
			expr.struct = Tab.noType;
			return;
		}
		expr.struct = Tab.intType;
	}
	
	public void visit(MinusExpr expr) {
		expr.struct = Tab.intType;
	}

	public void visit(AddopTerms addop) {
		if (addop.getTerm().struct != Tab.intType) {
			report_error("Term za addop mora biti tipa int", addop);
			addop.struct = Tab.noType;
			return;
		}
		addop.struct = Tab.intType;
	}
	
	
	public void visit(Term term) {
		//ako je mulopFactorList prazan, onda je term samo faktor
		if(term.getMulopFactorList() instanceof NoMulopFactors) {
			term.struct = term.getFactor().struct;
			return;
		}
		
		if (term.getFactor().struct != Tab.intType || ((MulopFactors)term.getMulopFactorList()).getFactor().struct != Tab.intType) {
			report_error("tokom Mulop i factor i mulopfactorlist moraju biti tipa int", term);
			term.struct = Tab.noType;
			return;
		}
		term.struct = Tab.intType;
		
	}
	
	public void visit(MulopFactors mulopfl) {
		if(mulopfl.getFactor().struct != Tab.intType) {
		report_error("tokom mulopfactors factor mora biti tipa int", mulopfl);
		}
	}
	
	public void visit(DesignatorFactor factor) {
		Obj obj = factor.getDesignator().obj;
		factor.struct = Tab.noType;
		if (obj == Tab.noObj) {
			report_error("Designator [" + obj.getName() + "] ne postoji", factor);
			return;
		}
		/*
		if (obj.getKind() == Obj.Meth) {
			report_error(String.format("Ime funkcije [%s] ne sme samo figurisati u izrazu (mora se pozvati)", obj.getName()), factor);
			return;
		}*/
		factor.struct = obj.getType();
	}
	
	
	//provera parametetara za len:
	public boolean lenParamsOK(Struct param) {
		if (param.getKind() != Struct.Array) {
			return false;
		}
		return true;

		/*//zeleo sam da dopustam samo ugradjene parametre, ali moze i bool, pa preskacem ovu proveru
		int kind = param.getElemType().getKind();
		return (kind == Struct.Char || kind == Struct.Int);*/
	}
	
	//poziv funkcije
	public void callFunc(Obj obj, SyntaxNode node) {
		String name = obj.getName();
		
		if(namespaceOpen) {
			//puno ime smestamo u tabelu
			name = currNamespace + name;
		}
		report_info("poziv f-je [" + name + ']', node);

		if (obj.getKind() != Obj.Meth) {
			report_error("moras da budes tipa Meth da bih te pozvao!", node);
			return;
		}

		//pokupi parametre funkcije...
		ArrayList<Struct> curr = funStack.pop();
		//uhvati podatke za tekucu funkciju
		FunctionData fd = allFunctions.get(name);
		//uhvati kontrolnu grupu za argumente
		ArrayList<Struct> supposed = fd.arguments;
		//proveravamo broj parametara
		if (curr.size() != supposed.size()) {
			String form = "funkcija [%s] ocekuje [%d] parametara a dobila je [%d]";
			report_error(String.format(form, name, fd.parCount, curr.size()), node);
			return;
		}

		//uverili smo se da je ok broj parametara
		//
		for (int i = 0; i < curr.size(); i++) {
			if (name.equals("len")) {
				if (!lenParamsOK(curr.get(i))) {
					String form = "argument f-je [len] mora biti niz intova ili charova, a dobio sam: (%s)";
					report_error(String.format(form, structToString(curr.get(i))), node);
				}
			}
			//provera parametar po parametar
			else if (!curr.get(i).equals(supposed.get(i))) {
				String form = "%d. parametar funkcije [%s] ne odgovara. Ocekuje se tip (%s) a dobijen je tip (%s)";
				report_error(String.format(
						form, i+1, name, structToString(supposed.get(i)), structToString(curr.get(i))), node);
			}
		}
	}
	
	//ovo je zapravo poziv funkcije bez parametara
	public void visit(DesignatorParen factor) {
		prepareForParameters(factor.getDesignator());
		Obj obj = factor.getDesignator().obj;
		factor.struct = obj.getType();
		if (obj.getType() == Tab.noType) {
			report_error("void funkcija ne moze biti u izrazu", factor);
		}
		callFunc(obj, factor);
	}
	
	//isti kod kao i za varijantu iznad
	public void visit(DesignatorActPars factor) {
		//prepareForParameters(factor.getDesignator());
		Obj obj = factor.getDesignator().obj;
		factor.struct = obj.getType();
		if (obj.getType() == Tab.noType) {
			report_error("void funkcija ne moze biti u izrazu", factor);
		}
		callFunc(obj, factor);
	}
	
	public void visit(ConstFactor factor) {
		factor.struct = factor.getChooseConst().obj.getType();
	}
	
	public void visit(NewArray factor) {
		if (factor.getExpr().struct != Tab.intType) {
			report_error("Samo int moze da udje u uglaste zagrade!", factor);
			factor.struct = Tab.noType;
			return;
		}
		factor.struct = new Struct(Struct.Array, factor.getType().struct);
	}
	
	public void visit(NewActPars factor) {
		//ovo ne radimo jer je za c nivo :)))))))
	}
	
	public void visit(NewParen factor) {
		//i ovo se preskace :)))))
	}

	public void visit(ParenExprFactor factor) {
		factor.struct = factor.getExpr().struct;
	}
	
	
	//designatori DODATI I ZA FULL NAMESPACE
	public void visit(DesignatorName desig) {
		String name = desig.getName();
		
		if(namespaceOpen) {
			name = currNamespace + name;
		}
		
		
		desig.obj = Tab.find(name);
		if (desig.obj == Tab.noObj) {
			report_error(String.format("Ime designatora [%s] ne postoji", desig.getName()), desig);
		}
	}

	public void visit(DesignatorFullName desig) {
		String name = desig.getName();
		String ns = desig.getNs();
		
		name = ns + "::" + name;
		
		desig.obj = Tab.find(name);
		if (desig.obj == Tab.noObj) {
			report_error(String.format("Ime designatora [%s] ne postoji", name), desig);
		}
	}
	
	//obradjuje i skalar i niz
	public void visit(DesignatorNormal desig) {
		Obj kid = desig.obj = desig.getDesignatorName().obj;
		
		if(desig.getParent() instanceof DesignatorActPars || desig.getParent() instanceof DesignatorStatementActPars) {
			prepareForParameters(desig);
		}
		
		if(desig.getDesignatorDotList() instanceof DesignatorDotsArray) {

			Struct kidType = kid.getType();
			desig.obj = Tab.noObj;
			//Mogucnost greske! Kastabiblnost
			if (((DesignatorDotsArray)desig.getDesignatorDotList()).getExpr().struct != Tab.intType) {
				report_error(String.format("Tip izraza kojim se indeksira promenljiva [%s] mora biti int", desig.obj.getName()), desig);
				return;
			}
			if (kidType.getKind() != Struct.Array) {
				report_error(String.format("Promenljiva [%s] mora biti niz", kid.getName()), desig);
				return;
			}

			desig.obj = new Obj(Obj.Elem, kid.getName(), kidType.getElemType());
			return;
		}
		
		else if(desig.getDesignatorDotList() instanceof DesignatorDotsArrayNoExpr) {
			Struct kidType = kid.getType();
			desig.obj = Tab.noObj;
			
			if (kidType.getKind() != Struct.Array) {
				report_error(String.format("Promenljiva [%s] mora biti niz", kid.getName()), desig);
				return;
			}

			desig.obj = new Obj(Obj.Elem, kid.getName(), kidType.getElemType());
			return;
			
		}
		
	}
	
	public void visit(DesignatorFull desig) {
		Obj kid = desig.obj = desig.getDesignatorFullName().obj;
		
		if(desig.getParent() instanceof DesignatorActPars || desig.getParent() instanceof DesignatorStatementActPars) {
			prepareForParameters(desig);
		}
		
		if(desig.getDesignatorDotList() instanceof DesignatorDotsArray) {

			Struct kidType = kid.getType();
			desig.obj = Tab.noObj;
			//Mogucnost greske! Kastabiblnost
			if (((DesignatorDotsArray)desig.getDesignatorDotList()).getExpr().struct != Tab.intType) {
				report_error(String.format("Tip izraza kojim se indeksira promenljiva [%s] mora biti int", desig.obj.getName()), desig);
				return;
			}
			if (kidType.getKind() != Struct.Array) {
				report_error(String.format("Promenljiva [%s] mora biti niz", kid.getName()), desig);
				return;
			}

			desig.obj = new Obj(Obj.Elem, kid.getName(), kidType.getElemType());
			return;
		}
		
		else if(desig.getDesignatorDotList() instanceof DesignatorDotsArrayNoExpr) {
			Struct kidType = kid.getType();
			desig.obj = Tab.noObj;
			
			if (kidType.getKind() != Struct.Array) {
				report_error(String.format("Promenljiva [%s] mora biti niz", kid.getName()), desig);
				return;
			}

			desig.obj = new Obj(Obj.Elem, kid.getName(), kidType.getElemType());
			return;
			
		}
		
	}
	
	public void visit(DesignatorStatementAssignop desig) {
		Obj d = desig.getDesignator().obj;
		Struct e = desig.getExpr().struct;

		if (!e.assignableTo(d.getType())) {
			report_error("kompatibilnost!! tip promenljive [" + d.getName() + "] se ne poklapa sa tipom dodeljene vrednosti", desig);
		}
		if (d.getKind() != Obj.Var && d.getKind() != Obj.Elem) {
			report_error("designator [" + d.getName() + "] mora biti promenljiva ili element niza", desig);
		}
	}
	
	public void visit(DesignatorStatementIncrement desig) {
		Obj obj = desig.getDesignator().obj;

		if (obj.getType() != Tab.intType || (obj.getKind() != Obj.Var && obj.getKind() != Obj.Elem)) {
			report_error("moze se inkrementirati samo integer", desig);
		}
	}

	public void visit(DesignatorStatementDecrement desig) {
		Obj obj = desig.getDesignator().obj;

		if (obj.getType() != Tab.intType || (obj.getKind() != Obj.Var && obj.getKind() != Obj.Elem)) {
			report_error("moze se dekrementirati samo integer", desig);
		}
	}

	//funkcija bez parametara
	public void visit(DesignatorStatementParen desig) {
		prepareForParameters(desig.getDesignator());
		Obj obj = desig.getDesignator().obj;
		callFunc(obj, desig);
	}
	
	//funkcija sa parametrima istooo
	public void visit(DesignatorStatementActPars desig) {
		//prepareForParameters(desig.getDesignator());
		Obj obj = desig.getDesignator().obj;
		callFunc(obj, desig);
	}
	
	//weird?
	public void visit(DesignatorStatementWeird desig) {
		
		if(desig.getDesignatorNiz().obj.getType().getKind() != Struct.Array) {
			report_error("sa desne strane se mora nalaziti niz", desig);
		}
		
		//Ovo je za B nivo, bye bye!
		
	}
	
	//koristi se kod designatora i kod factora gde imamp ActPars in Parens!
	public void prepareForParameters(Designator fun) {
		ArrayList<Struct> l = new ArrayList<>();
		funStack.push(l);
		report_info("fun " + fun.obj.getName(), fun);
	}
	
	public void visit(ActPars act) {
		report_info("par " + structToString(act.getExpr().struct), act);
		ArrayList<Struct> lst = funStack.peek();
		lst.add(act.getExpr().struct);
	}
	
	public void visit(ExprRelopExproCondFact cond) {
		Struct s1 = cond.getExpr().struct;
		Struct s2 = cond.getExpr1().struct;
		if (!s1.compatibleWith(s2)) {
			report_error("ne valja kompatibilnost!", cond);
			return;
		}
		Relop r = cond.getRelop();
		if (s1.getKind() == Struct.Array && !(r instanceof Equals) && !(r instanceof NEqual)) {
			report_error("nizovi se mogu porediti znakovima = i !=", cond);
		}
	}

	public void visit(ExprCondFact cond) {
		if (cond.getExpr().struct != booleanType) {
			report_error("uslov mora biti tipa boolean", cond);
		}
	}
	
	
	public void visit(BreakStatement stmt) {
		if (loopCount < 1) {
			report_error("break ne sme biti van petlje", stmt);
		}
	}

	public void visit(ContinueStatement stmt) {
		if (loopCount < 1) {
			report_error("continue ne sme biti van petlje", stmt);
		}
	}

	public void visit(PrintStatementNormal stmt) {
		Struct type = stmt.getExpr().struct;
		if (!type.equals(Tab.charType) && !type.equals(Tab.intType) && !type.equals(booleanType)) {
			report_error("print expr mora biti [char, bool, int]. dat izraz: (" + structToString(type) + ')', stmt);
		}
	}
	
	public void visit(PrintStatementConst stmt) {
		Struct type = stmt.getExpr().struct;
		if (!type.equals(Tab.charType) && !type.equals(Tab.intType) && !type.equals(booleanType)) {
			report_error("print expr mora biti [char, bool, int]. dat izraz: (" + structToString(type) + ')', stmt);
		}
	}
	
	public void visit(ReadStatement stmt) {
		Obj obj = stmt.getDesignator().obj;
		Struct type = obj.getType();
		if (!type.equals(Tab.charType) && !type.equals(Tab.intType) && !type.equals(booleanType)) {
			report_error("read statement mora biti [char, bool, int]. dat izraz: (" + structToString(type) + ')', stmt);
		}
	}

	
	
	public void visit(OpenNamespace ns) {
		String name = ns.getName();
		currNamespace = name + "::";
		namespaceOpen = true;
		report_info("otvoren je namespace " + currNamespace, ns);
	}
	
	public void visit(Namespaces ns) {
		report_info("zatvoren je namespace " + currNamespace, ns);
		currNamespace = "";
		namespaceOpen = false;
	}
	
	public boolean passed() {
		return !errorDetected;
	}
	
}

